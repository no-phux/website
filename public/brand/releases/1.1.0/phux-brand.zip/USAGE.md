# PHUX — Sculptural Fox

Sculptural Fox is the shared PHUX identity, selected on 2026-10-24 from the
combined 01 + 02 exploration. Its folded plates, pointed ears and right-facing
sweep appear unchanged across desktop, iOS, Android, the website and docs.

Use `logos/fox.svg` for the titanium treatment, `logos/fox-light.svg` on dark
surfaces and `logos/fox-dark.svg` on light surfaces. All are true vectors.
The supplied lockup spells **phux**, in lowercase. Keep its proportions.

Graphite #171A1E and warm stone #E7E2DA are the identity colors. The metallic
finish belongs to the artwork; product interaction colors, accessible themes
and typography remain product-owned. Do not add a neon glow or place artwork
inside another app-icon tile. Preserve clear space of at least one ear height.
For very small marks use a supplied monochrome variant. Do not mirror, stretch,
rotate, recolor individual plates or recreate the fox per platform.

Desktop has a rounded graphite tile. iOS uses the platform's own mask and ships
standard, dark and tinted appearances. Android includes adaptive and monochrome
vectors with the complete fox inside the platform safe area. The in-app iOS
mark uses the same generated Bézier geometry and respects Reduce Motion.

`mobile-mark.json` in the private source repository is the canonical vector
master. `just render-mobile` derives all icons, vector variants, wordmark and
Swift geometry deterministically. Changes ship as a new immutable release;
consumer repositories pin its version, source revision and SHA-256 digest.

These files identify PHUX. They do not grant endorsement or rights in the PHUX
name. Code license notices in LICENSES apply to their corresponding code;
original explorations and third-party reference artwork are not in this kit.
