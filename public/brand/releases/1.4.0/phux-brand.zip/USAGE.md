# PHUX brand profiles

The shared release default is recorded in `identity/profile.json`. Emblem Fox,
Flat Fox, Silver Fox and Classic Prompt are approved options, shared across desktop, iOS,
Android, website and docs. Select one in the private source library with
`just profile <id>` and publish a reviewed release to update consumers.

Use `logos/mark.svg` for the selected treatment, `logos/mark-light.svg` on dark
surfaces and `logos/mark-dark.svg` on light surfaces. All are true vectors.
The supplied lockup spells **phux**, in lowercase. Keep its proportions.

Emblem Fox uses warm stone #E7E2DA on ink #090A0C, and ships a variant per
bundled app theme in that theme's foreground and background.
Flat Fox and Silver Fox use graphite #171A1E and warm stone #E7E2DA.
Classic Prompt uses mint #8FDFC0 on ink #090A0C. The metallic
finish belongs to the artwork; product interaction colors, accessible themes
and typography remain product-owned. Do not add a neon glow or place artwork
inside another app-icon tile. Preserve clear space of at least one quarter of the mark’s height.
For very small marks use a supplied monochrome variant. Do not mirror, stretch,
rotate, recolor individual plates or recreate the fox per platform.

Desktop has a rounded graphite tile. iOS uses the platform's own mask and ships
standard, dark and tinted appearances. Android includes adaptive and monochrome
vectors with the complete fox inside the platform safe area. The in-app iOS
mark uses the same generated Bézier geometry and respects Reduce Motion.

`profiles.json` in the private source repository selects the approved vector
master and finish. `just render-mobile` derives all icons, vector variants, wordmark and
Swift geometry deterministically. Changes ship as a new immutable release;
consumer repositories pin its version, source revision and SHA-256 digest.

Native apps may offer a device-local Appearance choice from the bundled
`runtime/` profiles. Each choice supplies its own icons and mark; it does not
change the public website or the release default. The apps use native icon
selection without modifying signed application bundles.

These files identify PHUX. They do not grant endorsement or rights in the PHUX
name. Code license notices in LICENSES apply to their corresponding code;
original explorations and third-party reference artwork are not in this kit.
