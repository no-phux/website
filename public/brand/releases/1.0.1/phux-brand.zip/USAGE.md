# PHUX brand assets

Use the supplied artwork when referring to PHUX. Keep proportions, preserve
legibility, and choose a variant that works on the intended background.
Describe integrations accurately; artwork must not suggest an endorsement
or an official PHUX product where one does not exist.

The release manifest identifies every exported file and records its source
revision and checksum. The first release preserves the existing desktop,
mobile, documentation, and website variants; it does not choose a new logo.

Existing upstream licenses continue to apply to imported artwork. Files
imported from no-phux/phux and no-phux/website retain their Apache-2.0
license. Mobile artwork is PHUX project artwork supplied for identifying
the product. Review permission with the maintainer before other reuse.
Unreviewed explorations, purchased media, and private design originals are
excluded from this kit.
